--[[
name: webbridge
version: 1.4.3
update: 2012.10.10
]]
local log = require "framework.log"
local apps = require "framework.apps"
local services = require "framework.services"
local ui = require "framework.ui"
local storage = require "framework.storage"
local utils = require "framework.utils"
local mba = require "framework.mba"
local phone = require "framework.phone"
local tabs = require "framework.tabs"
local json = require "json"

function setTitle(configStr)
	if title then
	local config = json.decode(configStr)
		
		if config.label then
			title.label = config.label
		end
		
		if config.url then
			title.onclick = "executeURL(" .. json.encode(config.url) .. ")"
		end
	end
end
		
function setToolBar(configStr)
	if toolbar then
		local config = json.decode(configStr)
	
		toolbar:removeAllChildren()
		
		toolbar:addChild({qName="space"})
		
		for idx,item in ipairs(config) do
			item.qName = "button"
			item.border = "border"
			if item.url then
				item.onclick = "executeURL(" .. json.encode(item.url) .. ")"
			end
			toolbar:addChild(item)
		end
		
		toolbar:addChild({qName="space"})
	end
end

function setNavBar(configStr)
	local config = json.decode(configStr)

	if not toolbarview then
		local view = ui.view()
		view.height = 44
		view.id = "toolbarview"
		main:addChild(view, 0)
	end

	if toolbarview then
		toolbarview:removeChildById("navbar")

		local tb = ui.toolbar()
		tb.height = "100%"
		tb.id = "navbar"

		local left = config.leftButton
		if left then
			if #(left) == 0 then
				left.qName = "button"
				left.border = "true"
				if left.url then
					left.onclick = "executeURL(" .. json.encode(left.url) .. ")"
				end
				tb:addChild(left)
			else
				for idx,item in ipairs(left) do
					item.qName = "button"
					item.border = "true"
					if item.url then
						item.onclick = "executeURL(" .. json.encode(item.url) .. ")"
					end
					tb:addChild(item)
				end
			end
		end

		tb:addChild({qName="space"})

		local right = config.rightButton
		if right then
			if #(right) == 0 then
				right.qName = "button"
				right.border = "true"
				if right.url then
					right.onclick = "executeURL(" .. json.encode(right.url) .. ")"
				end
				tb:addChild(right)
			else
				for idx,item in ipairs(right) do
					item.qName = "button"
					item.border = "true"
					if item.url then
						item.onclick = "executeURL(" .. json.encode(item.url) .. ")"
					end
					tb:addChild(item)
				end
			end
		end
		toolbarview:addChild(tb, 0)

		if not config.title then
			config.title = ""
		end

		if not titleLabel then
			local lb = ui.label()
			lb.id = "titleLabel"
			lb.text = config.title
			lb.fontSize = 20
			lb.color = "#FFFFFF"
			lb.align = "center"
			toolbarview:addChild(lb)
		else
			titleLabel:setText(config.title)
		end
	end
end

function executeURL(url)
	local prefix = "javascript:"
	if string.sub(url,1,string.len(prefix)) == prefix then
		local js = string.sub(url, string.len(prefix) + 1)
		if webview then
			webview:execute(js)
		end
	else
		if webview then
			webview:loadURL(url)
		end
	end
end

function refreshProfile()
	ui.startBusy()
	pcall(services.refresh, true)
	ui.stopBusy()

	sandbox:getGlobalSandbox():put_value("$dashboardRefresh", "true")
end

function refreshApps()
	ui.startBusy()
	pcall(services.refreshApps)
	ui.stopBusy()

	sandbox:getGlobalSandbox():put_value("$dashboardRefresh", "true")
end

function exit()
	apps.popPage()
end

function logout(arg)
	if arg then
		arg = json.decode(arg)
		local title = arg.title
		if not title then
			title = "登录状态过期"
		end
		local message = arg.message
		alert(title, message, "重新登录")
	else
		alert("登录状态过期", "为了保证账号安全，请重新登录。", "重新登录")
	end
	services.logout()
	apps.pop("Login")
end

function switchTab(tabname)
	if tabname then
		tabs.switch(tabname)
	end
end

function showMessage(arg)
	arg = json.decode(arg)
	local title = arg.title
	local message = arg.message
	local expireTime = arg.expireTime
	if expireTime == 0 then
		alert(title, message, "知道了")
	else
		webview:showMessage(arg)
	end
end

function callNumber(args)
	phone.callPhone(args)
end

function smsNumber(args)
	phone.smsPhone(args)
end
