local base = require "framework.base"
local utils = require "native.utils"
local json = require "cjson"
local storage = require "framework.storage"
local algorithm = require "algorithm"

local table = table
local pairs = pairs
local print = print
local string = string
local alert = alert

local nativehttp = http
local http = require "native.http"

local function http_post(headers, url, body)
	if isAndroid or ios43 then
		if type(headers) == "table" then
			headers = json.encode(headers)
		end
		local ret = http.curl("POST", headers, url, body)

		if type(ret) ~= "table" then
			ret = json.decode(ret)
		end

		if ret.status and not ret.responseCode then
			ret.responseCode = ret.status
		end

		return ret
	else
		return nativehttp.post{
			url = url,
			body = body,
			headers = headers
		}
	end
end

local CLIENT_ID = "fb411b36-f141-4cda-8af7-640a16bdf641"
local CLIENT_SECRET = "672c5599-a6cf-4d62-ba5f-dd308d45224e"
local SERVER_URL

local server = base.getGSandbox():getMap("env"):get("server")
if server == "dev" then
	SERVER_URL = "http://dev.marykayintouch.com.cn/OAuthServer/OAuth/Token"
elseif server == "qa" then
	SERVER_URL = "http://qa.marykayintouch.com.cn/OAuthServer/OAuth/Token"
elseif server == "stg" then
	SERVER_URL = "http://staging.marykayintouch.com.cn/OAuthServer/OAuth/Token"
elseif server == "prod" or server == "us" then
	CLIENT_ID = "662ab38b-f0db-453e-8b75-1c4aeebd9e12"
	CLIENT_SECRET = "b5fd1791-c674-4791-8b2e-fc61e7adcc32"
	SERVER_URL = "https://oauth.marykayintouch.com.cn/OAuthServer/OAuth/Token"
else
	CLIENT_ID = "662ab38b-f0db-453e-8b75-1c4aeebd9e12"
	CLIENT_SECRET = "b5fd1791-c674-4791-8b2e-fc61e7adcc32"
	SERVER_URL = "https://oauth.marykayintouch.com.cn/OAuthServer/OAuth/Token"
end

module(...)

function getAccessToken()
local ACCESS_TOKEN = base.getGSandbox():get("ACCESS_TOKEN")
	if not ACCESS_TOKEN then
		update()
	end
	return ACCESS_TOKEN
end

function setAccessToken(value)
	base.getGSandbox():put_value("ACCESS_TOKEN", value)
end

function getRefreshToken()
	local REFRESH_TOKEN = base.getGSandbox():get("REFRESH_TOKEN")
	if not REFRESH_TOKEN then
		REFRESH_TOKEN = storage.load("REFRESH_TOKEN", storage.SCOPE_GLOBAL)
		if REFRESH_TOKEN then
			REFRESH_TOKEN = algorithm.aes_decrypt(algorithm.hex2data(REFRESH_TOKEN))
		end
	end

	return REFRESH_TOKEN
end

function clean()
	storage.save("REFRESH_TOKEN", nil, storage.SCOPE_GLOBAL)
	base.getGSandbox():put_value("REFRESH_TOKEN", nil)
	base.getGSandbox():put_value("ACCESS_TOKEN", nil)
end

function setRefreshToken(value)
	base.getGSandbox():put_value("REFRESH_TOKEN", value)
	
	if value then
		storage.save("REFRESH_TOKEN", algorithm.data2hex(algorithm.aes_encrypt(value)), storage.SCOPE_GLOBAL)
	else
		storage.save("REFRESH_TOKEN", nil, storage.SCOPE_GLOBAL)
	end
end

local ios43 = false

local deviceinfo = base.getGSandbox():get("$deviceInfo")
local isAndroid = deviceinfo:get("os.name") == "ANDROID"
if deviceinfo:get("os.name") == "IOS" then
	if string.sub(deviceinfo:get("os.version"), 1, 2) == "4." then
		ios43 = true
	end 
end

function update()
	local REFRESH_TOKEN = getRefreshToken()
	if not REFRESH_TOKEN then
	    print("no REFRESH_TOKEN on update AT, ignore")
	    return false
	end
	
	local params = {
		grant_type = "refresh_token",
		refresh_token = REFRESH_TOKEN,
		client_id = CLIENT_ID,
		client_secret = CLIENT_SECRET
	}
	local tb = {}
	for k,v in pairs(params) do
		table.insert(tb, string.format("%s=%s", k, utils.urlencode(v)))
	end

	local body = table.concat(tb, "&")

	-- print("UPDATE AT POST", SERVER_URL, body)
	local ret = http_post({
			["Content-Type"] = "application/x-www-form-urlencoded"
		}, SERVER_URL, body)

	if ret.responseCode == 200 and ret.body then
		local map = json.decode(ret.body)

		if map.ErrorCode then
			print(ret.body)
			return false
		else
			if map.access_token then
				base.getGSandbox():put_value("ACCESS_TOKEN", map.access_token)
				print("new ACCESS_TOKEN:", map.access_token)
			end

			if map.refresh_token then
				base.getGSandbox():put_value("REFRESH_TOKEN", map.refresh_token)
				storage.save("REFRESH_TOKEN", algorithm.data2hex(algorithm.aes_encrypt(map.refresh_token)), storage.SCOPE_GLOBAL)
				print("new REFRESH_TOKEN:", map.refresh_token)
			end

			return true
		end
	else
		print(ret.responseCode, ret.body)
		return false
	end
end
