---
-- @module framework.ui

local nativeconfirm = confirm
local nativealert = alert

module(..., package.seeall)

require "native.ui"         local ui = native.ui

-------------------------------------------------------------------------------
-- The value of CONFIRM_OK.
-- @field [parent=#framework.ui] CONFIRM_OK
CONFIRM_OK = 1

-------------------------------------------------------------------------------
-- The value of CONFIRM_CANCEL.
-- @field [parent=#framework.ui] CONFIRM_CANCEL
CONFIRM_CANCEL = 0

-------------------------------------------------------------------------------
-- Function startBusy
-- @function [parent=#framework.ui] startBusy
function startBusy(ycenter, title)
    ui.startBusy(ycenter, title)
end

-------------------------------------------------------------------------------
-- Function stopBusy
-- @function [parent=#framework.ui] stopBusy
function stopBusy()
    ui.stopBusy()
end

-------------------------------------------------------------------------------
-- Function alert
-- @function [parent=#framework.ui] alert
-- @param title
-- @param message
-- @param oktitle
function alert(title, message, ok)
    nativealert(title, message, ok)
end

-------------------------------------------------------------------------------
-- Function confirm
-- @function [parent=#framework.ui] confirm
-- @param title
-- @param message
-- @param oktitle
-- @param canceltitle
function confirm(title, message, ok, cancel)
	return nativeconfirm(title, message, ok, cancel)
end

-------------------------------------------------------------------------------
-- Function autoAsyncConfirm
-- @function [parent=#framework.ui] autoAsyncConfirm
-- @param title
-- @param message
-- @param oktitle
-- @param canceltitle
-- @param onOK
-- @param onCancel
function autoAsyncConfirm(title, message, ok, cancel, onOK, onCancel)
	if nativeconfirm then
        nativeconfirm(title, message, ok, cancel, onOK, onCancel)
	else
        if ui.confirm(title, message, ok, cancel, CONFIRM_CANCEL) == CONFIRM_OK then
        	onOK()
        else
        	onCancel()
        end
	end
end

-------------------------------------------------------------------------------
-- Function textfield
-- @function [parent=#framework.ui] textfield
-- @param table
function textfield(args)
    local m = {}
    m.qName = "textfield"
    m.backgroundColor = "#FFFFFF"
    m.backgroundAlpha = 1
    m.height = 44
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return m
end

-------------------------------------------------------------------------------
-- Function button
-- @function [parent=#framework.ui] button
-- @param table
function button(args)
    local m = {}
    m.qName = "button"
    m.height = 44
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return m
end

View = {}
View.__index = View

function View:addChild(child)
    local sub = self.subitems
    if not sub then
        sub = {}
        self.subitems = sub
    end
    
    table.insert(sub, child)
end

-------------------------------------------------------------------------------
-- Function view
-- @function [parent=#framework.ui] view
-- @param table
function view(args)
    local m = {}
    setmetatable(m, View)
    m.qName = "view"
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return m
end

-------------------------------------------------------------------------------
-- Function vbox
-- @function [parent=#framework.ui] vbox
-- @param table
function vbox(args)
    local m = {}
    setmetatable(m, View)
    m.qName = "vbox"
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return m
end

-------------------------------------------------------------------------------
-- Function hbox
-- @function [parent=#framework.ui] hbox
-- @param table
function hbox(args)
    local m = {}
    setmetatable(m, View)
    m.qName = "hbox"
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return m
end

-------------------------------------------------------------------------------
-- Function image
-- @function [parent=#framework.ui] image
-- @param table
function image(args)
    local m = {}
    m.qName = "image"
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return m
end

-------------------------------------------------------------------------------
-- Function label
-- @function [parent=#framework.ui] label
-- @param table
function label(args)
    local m = {}
    m.qName = "label"
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return m
end

-------------------------------------------------------------------------------
-- Function textarea
-- @function [parent=#framework.ui] textarea
-- @param table
function textarea(args)
    local m = {}
    m.qName = "textarea"
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return m
end

-------------------------------------------------------------------------------
-- Function scrollview
-- @function [parent=#framework.ui] scrollview
-- @param table
function scrollview(args)
    local m = {}
    setmetatable(m, View)
    m.qName = "scrollview"
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return m
end

-------------------------------------------------------------------------------
-- Function webview
-- @function [parent=#framework.ui] webview
-- @param table
function webview(args)
    local m = {}
    m.qName = "webview"
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return m
end

-------------------------------------------------------------------------------
-- Function switch
-- @function [parent=#framework.ui] switch
-- @param table
function switch(args)
    local m = {}
    m.qName = "switch"
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return m
end

-------------------------------------------------------------------------------
-- Function toolbar
-- @function [parent=#framework.ui] toolbar
-- @param table
function toolbar(args)
    local m = {}
    setmetatable(m, View)
    m.qName = "toolbar"
    m.height = 44
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return m
end

-------------------------------------------------------------------------------
-- Function toolbar_button
-- @function [parent=#framework.ui] toolbar_button
-- @param table
function toolbar_button(args)
    local item = {}
    item.qName = "button"
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return item
end

-------------------------------------------------------------------------------
-- Function toolbar_space
-- @function [parent=#framework.ui] toolbar_space
-- @param table
function toolbar_space(args)
    local item = {}
    item.type = "space"
    if args then
    	for k,v in pairs(args) do
    		m[k] = v
    	end
    end
    return item
end
