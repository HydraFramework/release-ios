---
-- @module framework.user

local islogin = false
local storage = require "framework.storage"
local json = require "json"
local base = require "framework.base"
local token = require "framework.token"

module(..., package.seeall)

-------------------------------------------------------------------------------
-- Function getUsername
-- @function [parent=#framework.user] getUsername
function getUsername()
    return storage.load("$username", storage.SCOPE_GLOBAL)
end

-------------------------------------------------------------------------------
-- Function setUsername
-- @function [parent=#framework.user] setUsername
-- @param name
function setUsername(name)
    storage.save("$username", name, storage.SCOPE_GLOBAL)
end

-------------------------------------------------------------------------------
-- Function getSecureCode
-- @function [parent=#framework.user] getSecureCode
function getSecureCode()
    return token.getAccessToken()
end

-------------------------------------------------------------------------------
-- Function setSecureCode
-- @function [parent=#framework.user] setSecureCode
-- @param code
-- @param expireTime
function setSecureCode(code, expireTime)
	base.getGSandbox():put_value("$securecode", code)

	if algorithm then
		local enc = algorithm.aes_encrypt(code)
		local hex = algorithm.data2hex(enc)
		
	    storage.save("$securecode", nil, storage.SCOPE_GLOBAL)
	    storage.save("$securecode_encrypted", hex, storage.SCOPE_GLOBAL, expireTime)
	else
	    storage.save("$securecode", code, storage.SCOPE_GLOBAL, expireTime)
	end
end

-------------------------------------------------------------------------------
-- Function getProfile
-- @function [parent=#framework.user] getProfile
function getProfile()
    local pro = base.getGSandbox():get("$profile")
    if pro then
    	return pro
    end

    local hex = storage.load("$profile_encrypted", storage.SCOPE_GLOBAL)
    if not hex then
		if not algorithm then
			pro = storage.load("$profile", storage.SCOPE_GLOBAL)
		end
	else
		local enc = algorithm.hex2data(hex)
		pro = algorithm.aes_decrypt(enc)
    end

    if pro then
        return json.decode(pro)
    end
    
    return {}
end

-------------------------------------------------------------------------------
-- Function setProfile
-- @function [parent=#framework.user] setProfile
-- @param profile
function setProfile(pro)
	if pro then
		base.getGSandbox():put_value("$sn", pro.serialNumber)
		base.getGSandbox():put_value("$profile", pro)
	else
		base.getGSandbox():remove("$sn")
		base.getGSandbox():remove("$profile")
	end
	
	if type(pro) == "table" then
		pro = json.encode(pro)
	end
	
	if algorithm then
		local enc = algorithm.aes_encrypt(pro)
		local hex = algorithm.data2hex(enc)
		
	    storage.save("$profile", nil, storage.SCOPE_GLOBAL)
	    storage.save("$profile_encrypted", hex, storage.SCOPE_GLOBAL)
	else
	    storage.save("$profile", pro, storage.SCOPE_GLOBAL)
	end
end

-------------------------------------------------------------------------------
-- Function getSerialNumber
-- @function [parent=#framework.user] getSerialNumber
function getSerialNumber()
	local sn = base.getGSandbox():get("$sn")
	if sn then
		return sn
	end
	
	local profile = getProfile()
	if profile then
		return profile.serialNumber
	end
	return nil
end

-------------------------------------------------------------------------------
-- Function isLogin
-- @function [parent=#framework.user] isLogin
function isLogin()
    return base.getGSandbox():get("$is_login") == "true"
end

-------------------------------------------------------------------------------
-- Function setLogin
-- @function [parent=#framework.user] setLogin
-- @param #boolean val
function setLogin(val)
    base.getGSandbox():put_value("$is_login", val and "true" or "false")
end