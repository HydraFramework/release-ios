---
-- @module framework.base
local gsandbox = nil
local dinfo = nil
local tokens = nil
local sizes = nil

local documentRoot = nil
local appRoot = nil

local serverURL = nil
local serversURL = nil

local screenWidth = 0
local screenHeight = 0


module(..., package.seeall)

-------------------------------------------------------------------------------
-- Function getGSandbox
-- @function [parent=#framework.base] getGSandbox
function getGSandbox()
	if gsandbox == nil then
		gsandbox = sandbox:getGlobalSandbox()
	end
	return gsandbox
end


-------------------------------------------------------------------------------
-- Function getScreenHeight
-- @function [parent=#framework.base] getScreenHeight
function getScreenHeight()
    if screenHeight == 0 then
        screenHeight = tonumber(getGSandbox():get("$deviceInfo"):get("device.resolutionHeight"))
    end
    
    return screenHeight
end

-------------------------------------------------------------------------------
-- Function getScreenWidth
-- @function [parent=#framework.base] getScreenWidth
function getScreenWidth()
    if screenWidth == 0 then
        screenWidth = tonumber(getGSandbox():get("$deviceInfo"):get("device.resolutionWidth"))
    end
    
    return screenWidth
end

-------------------------------------------------------------------------------
-- Function getDataFile
-- @function [parent=#framework.base] getDataFile
-- @param path
function getDataFile(path)
	if documentRoot == nil then
		documentRoot = sandbox:getDataPath()
	end
	return documentRoot .. "/" .. path
end

-------------------------------------------------------------------------------
-- Function resolveFile
-- @function [parent=#framework.base] resolveFile
-- @param path
function resolveFile(path)
    if appRoot == nil then
        appRoot = sandbox:getAppPath()
    end
    
    return appRoot .. "/" .. path
end

-------------------------------------------------------------------------------
-- Function getServerURL
-- @function [parent=#framework.base] getServerURL
function getServerURL()
	if serverURL == nil then
		serverURL = getGSandbox():get("$server")
	end
	return serverURL
end

-------------------------------------------------------------------------------
-- Function getSecureServerURL
-- @function [parent=#framework.base] getSecureServerURL
function getSecureServerURL()
	if serversURL == nil then
		serversURL = getGSandbox():get("$servers")
	end

    if serversURL == nil then
        serversURL = string.gsub(getServerURL(), "http://", "https://")
    end
	return serversURL
end

-------------------------------------------------------------------------------
-- Function getDeviceInfo
-- @function [parent=#framework.base] getDeviceInfo
function getDeviceInfo()
	if dinfo == nil then
		dinfo = getGSandbox():get("$deviceInfo")
	end
    return dinfo
end

-------------------------------------------------------------------------------
-- Function setToken
-- @function [parent=#framework.base] setToken
-- @param appId
-- @param token
function setToken(appId, token)
    if tokens == nil then
        tokens = getGSandbox():getMap("$tokens")
    end
    tokens:put_value(appId, token)
end

-------------------------------------------------------------------------------
-- Function getToken
-- @function [parent=#framework.base] getToken
-- @param appId
function getToken(appId)
    if tokens == nil then
        tokens = getGSandbox():getMap("$tokens")
    end
    return tokens:get(appId)
end

-------------------------------------------------------------------------------
-- Function setSize
-- @function [parent=#framework.base] setSize
-- @param appId
-- @param size
function setSize(appId, size)
    if sizes == nil then
        sizes = getGSandbox():getMap("$sizes")
    end
    sizes:put_value(appId, size)
end

-------------------------------------------------------------------------------
-- Function getSize
-- @function [parent=#framework.base] getSize
-- @param appId
function getSize(appId)
    if sizes == nil then
        sizes = getGSandbox():getMap("$sizes")
    end
    return sizes:get(appId)
end
