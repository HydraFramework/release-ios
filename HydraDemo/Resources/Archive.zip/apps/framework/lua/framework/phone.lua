---
-- @module framework.phone

module(..., package.seeall)

local phone = require "native.phone"
local log = require "framework.log"

local Phone = {}
Phone.__index = function(self, key)
    return phone[key]
end

Phone.__newindex = function(self, key, value)
    phone[key] = value
end

-------------------------------------------------------------------------------
-- The value of rotation.
-- @field [parent=#framework.phone] rotation

-------------------------------------------------------------------------------
-- Function callPhone
-- @function [parent=#framework.phone] callPhone
-- @param num
function callPhone(num)
    phone.callPhone(num)
end

-------------------------------------------------------------------------------
-- Function smsPhone
-- @function [parent=#framework.phone] smsPhone
-- @param num
function smsPhone(num)
    phone.smsPhone(num)
end

-------------------------------------------------------------------------------
-- Function isWLAN
-- @function [parent=#framework.phone] isWLAN
function isWLAN()
	if phone.isWLAN then
		return phone.isWLAN()
	end
	
	return true
end

setmetatable(_M, Phone)
