---
-- @module framework.http

module(..., package.seeall)

local nativehttp = http

local http = require "native.http"
local ui = require "framework.ui"
local apps = require "framework.apps"
local session = require "framework.session"
local base = require "framework.base"
local log = require "framework.log"
local utils = require "framework.utils"
local json = require "json"
local phone = require "framework.phone"
local Event = require "framework.event"
local secure = false
local cjson = require "cjson"
local ios43 = false

local deviceinfo = base.getGSandbox():get("$deviceInfo")
if deviceinfo:get("os.name") == "IOS" then
	if string.sub(deviceinfo:get("os.version"), 1, 2) == "4." then
		ios43 = true
	end 
end

local function curl(method, headers, path, body)
	if not string.find(path, "sessionId=") then
		local sessionId = session.getId()
		if sessionId then
			if not string.find(path, "[?]") then
				path = path .. "?sessionId=" .. sessionId
			else
				path = path .. "&sessionId=" .. sessionId
			end
		end
	end
	local serverURL = base.getServerURL()
	local secureURL = base.getSecureServerURL()
	if secure and secureURL and string.len(secureURL) > 0 then
		serverURL = secureURL
	end
	if log.isDebug() then
		if not body then
			log.debug("curl < " .. serverURL .. path)
		else
			log.debug("curl < " .. serverURL .. path .. " << " .. body)
		end
	end
	local retString = nil
	if nativehttp and (not ios43 or not secure) then
		if method == "POST" then
			retString = nativehttp.post({
				headers = headers,
				url = serverURL .. path,
				body = body
			})
		else
			retString = nativehttp.get({
				headers = headers,
				url = serverURL .. path
			})
		end
	else
		if type(headers) == "table" then
			headers = cjson.encode(headers)
		end
		retString = http.curl(method, headers, serverURL .. path, body)
	end
	local ret = retString

	if type(ret) ~= "table" then
		ret = json.decode(ret)
	end

	local status = ret.status and ret.status or ret.responseCode
	if status == 403 then
		local body = ret["body"]
		if body then
			local bodydic = json.decode(body)
			local code = bodydic["code"]
			local message = bodydic["message"]

			if code and message then
			--alert("Debug", message .. " code: " .. code, "OK")
			end

			if code == "2-2" then
				timer = setTimeout(function()
					Event.gpost(Event.FW_HTTP_403_2_2)
				end, 1)
			elseif code == "3-1" then
				local storage = require "framework.storage"
				storage.save("app.latest_relogin_body", nil, storage.SCOPE_GLOBAL) -- clear auto login

				timer = setTimeout(function()
					Event.gpost(Event.FW_HTTP_403_3_1)
				end, 1)
			elseif code == "1-2" then
				-- Forbidden ClientAppRevision
				if bodydic.updateUrl then
					local updateMessage = bodydic.updateMessage
					if not updateMessage then
						updateMessage = "您使用的版本过旧，需要更新后方能使用。"
					end
					if ui.confirm("提示", updateMessage, "更新", "取消并退出", ui.CONFIRM_CANCEL) == ui.CONFIRM_OK then
						utils.navigateURL(bodydic.updateUrl)
					end
					utils.exit(0)
				end
			end
		end
	end
	return ret
end

-------------------------------------------------------------------------------
-- Function setSecure
-- @function [parent=#framework.http] setSecure
-- @param isSecure
function setSecure(isSecure)
	secure = isSecure
end

-------------------------------------------------------------------------------
-- Function get
-- @function [parent=#framework.http] get
-- @param headers
-- @param path
function get(headers, path)
	return curl("GET", headers, path, nil)
end

-------------------------------------------------------------------------------
-- Function dump_get
-- @function [parent=#framework.http] dump_get
-- @param path
function dump_get(path)
	if not string.find(path, "sessionId=") then
		local sessionId = session.getId()
		if sessionId then
			if not string.find(path, "[?]") then
				path = path .. "?sessionId=" .. sessionId
			else
				path = path .. "&sessionId=" .. sessionId
			end
		end
	end

	local serverURL = base.getServerURL()
	local secureURL = base.getSecureServerURL()
	if secure and secureURL and string.len(secureURL) > 0 then
		serverURL = secureURL
	end

	return serverURL .. path
end

-------------------------------------------------------------------------------
-- Function post
-- @function [parent=#framework.http] post
-- @param headers
-- @param path
-- @param body
function post(headers, path, body)
	return curl("POST", headers, path, body)
end

-------------------------------------------------------------------------------
-- Function post_form
-- @function [parent=#framework.http] post_form
-- @param headers
-- @param path
-- @param body
function post_form(headers, path, body)
	if not headers then
		headers = {}
	end

	headers["Content-Type"] = "application/x-www-form-urlencoded"
	return post(headers, path, body)
end

-------------------------------------------------------------------------------
-- Function hasNetwork
-- @function [parent=#framework.http] hasNetwork
function hasNetwork()
	if not phone.isWLAN() then
		if ui.confirm("提示", "未找到WLAN，是否使用2g/3g网络下载?", "是", "否", ui.CONFIRM_CANCEL) == ui.CONFIRM_CANCEL then
			return false
		end
	end

	return true
end

-------------------------------------------------------------------------------
-- Function download
-- @function [parent=#framework.http] download
-- @param urlString
-- @param path
function download(urlString, path)
	if not hasNetwork() then
		return nil
	end
	return http.download(urlString, path)
end

-------------------------------------------------------------------------------
-- Function unzipURL
-- @function [parent=#framework.http] unzipURL
-- @param urlString
-- @param path
-- @param withOutCache
function unzipURL(urlString, path, withOutCache)
	if not hasNetwork() then
		return nil
	end
	return http.unzipURL(urlString, path, withOutCache)
end
