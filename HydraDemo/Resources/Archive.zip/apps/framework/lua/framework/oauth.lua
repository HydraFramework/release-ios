---
-- @module framework.oauth

module(..., package.seeall)

local ui = require "framework.ui"
local utils = require "framework.utils"
local Event = require "framework.event"

-------------------------------------------------------------------------------
-- The value of APP_LAUNCH.
-- @field [parent=#framework.track] APP_LAUNCH
APP_LAUNCH = 0x100

function create_auth2(auth_url, access_token_url, clientid, secret, redirect)
	local body = {
		authURL = auth_url
			.. "?client_id=" .. clientid
			.. "&response_type=code&redirect_uri=" .. utils.urlencode(redirect),
		accessTokenURL = access_token_url
			.. "?client_id=" .. clientid
			.. "&client_secret=" .. secret
			.. "&grant_type=authorization_code&redirect_uri=" .. redirect
	}
	
	body.auth = function(onsuccf, onfailedf)
		if body.access_token then
			if body.expires_time > os.time() then
				onsuccf()
				return
			end
		end

		local url = body.authURL

		local eventHandle = nil
		eventHandle = Event.gbind(Event.HANDLE_OPEN_URL, function(e)
			Event.unbind(eventHandle)
			eventHandle = nil
			--collectgarbage()
			
			local backurl = e.url
			local code = nil
			if backurl then
				local st,ed = string.find(backurl, "?code=")
				if ed then
					code = string.sub(backurl, ed + 1)
				end
			end

			if code then
				local fetchatokenurl = body.accessTokenURL .. "&code=" .. code
				
				ui.startBusy()
				http.post{
					url = fetchatokenurl,
					method = "POST",
					onsuccess = function(resp)
						ui.stopBusy()
						local result = json.decode(resp.body)
						for k,v in pairs(result) do
							body[k] = v
						end

						body.expires_time = os.time() + tonumber(body.expires_in)
						if onsuccf then
							onsuccf()
						end
					end,
					onfailed = function(resp)
						ui.stopBusy()
						if onfailedf then
							onfailedf(resp)
						end
					end
				}
			else
				if onfailedf then
					onfailedf(backurl)
				end
			end
		end)

		utils.navigateURL(url)
	end

	return body
end


-------------------------------------------------------------------------------
-- Function weibo
-- @function [parent=#framework.oauth] auth
-- @param clientid
-- @param secret
-- @param redirect
function weibo(clientid, secret, redirect)
	return create_auth2("https://api.weibo.com/oauth2/authorize", "https://api.weibo.com/oauth2/access_token", clientid, secret, redirect)
end