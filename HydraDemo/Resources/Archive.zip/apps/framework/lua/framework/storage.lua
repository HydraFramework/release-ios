---
-- @module framework.storage
local storage = require "native.storage"
local utils = require "framework.utils"

module(..., package.seeall)

-------------------------------------------------------------------------------
-- The value of SCOPE_GLOBAL.
-- @field [parent=#framework.storage] SCOPE_GLOBAL
SCOPE_GLOBAL = 0

-------------------------------------------------------------------------------
-- The value of SCOPE_APP.
-- @field [parent=#framework.storage] SCOPE_APP
SCOPE_APP = 1

-------------------------------------------------------------------------------
-- The value of SCOPE_APP.
-- @field [parent=#framework.storage] SCOPE_APP
SCOPE_PAGE = 2

-------------------------------------------------------------------------------
-- Function load
-- @function [parent=#framework.storage] load
-- @param key
-- @param scope
function load(key, sc)
    if not sc then
        sc = SCOPE_APP
    end
    
    if sc == SCOPE_GLOBAL then
        return storage.load(key, "$global")
    elseif sc == SCOPE_APP then
        return storage.load(key, utils.getAppId(sandbox))
    elseif sc == SCOPE_PAGE then
        return storage.load(key, utils.getAppId(sandbox) .. ":" .. sandbox:getPageId())
    else
        return storage.load(key, sc)
    end
end

-------------------------------------------------------------------------------
-- Function setId
-- @function [parent=#framework.storage] setId
-- @param key
-- @param value
-- @param scope
-- @param timeout
function save(key, value, sc, timeout)
    if not sc then
        sc = SCOPE_APP
    end
    
    if sc == SCOPE_GLOBAL then
        return storage.save(key, value, "$global", timeout)
    elseif sc == SCOPE_APP then
        return storage.save(key, value, utils.getAppId(sandbox), timeout)
    elseif sc == SCOPE_PAGE then
        return storage.save(key, value, utils.getAppId(sandbox) .. ":" .. sandbox:getPageId(), timeout)
    else
        return storage.save(key, value, sc, timeout)
    end
end
