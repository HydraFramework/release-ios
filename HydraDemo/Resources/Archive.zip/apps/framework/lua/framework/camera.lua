module(..., package.seeall)

function takePhoto(option)
	if option.allowsCrop then
    	helper:advancedTakePhoto(option)
	else
    	helper:takePhoto(option)
	end
end
