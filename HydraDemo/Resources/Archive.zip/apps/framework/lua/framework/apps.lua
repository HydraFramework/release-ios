---
-- @module framework.apps

module(..., package.seeall)

local apps = require "native.apps"
local phone = require "framework.phone"
local ui = require "framework.ui"
local utils = require "framework.utils"
-------------------------------------------------------------------------------
-- Function install
-- @function [parent=#framework.apps] install
-- @param urlString
-- @param appId
-- @param existVersion
function install(urlString, appId, existVersion)
    return apps.install(urlString, appId, existVersion)
end

-------------------------------------------------------------------------------
-- Function supportLazy
-- @function [parent=#framework.apps] supportLazy
function supportLazy()
	return apps.supportLazy ~= nil and apps.supportLazy()
end

-------------------------------------------------------------------------------
-- Function pushNative
-- @function [parent=#framework.apps] pushNative
-- @param name
-- @param param
function pushNative(name, param)
    return apps.pushNative(name, param)
end

-------------------------------------------------------------------------------
-- Function remove
-- @function [parent=#framework.apps] remove
-- @param appId
function remove(appId)
    return apps.remove(appId)
end

-------------------------------------------------------------------------------
-- Function switch
-- @function [parent=#framework.apps] switch
-- @param appId
-- @param animation
function switch(appId, animation)
    if not animation then
        animation = false
    end
    return apps.switch(appId, animation)
end

-------------------------------------------------------------------------------
-- Function switchPage
-- @function [parent=#framework.apps] switchPage
-- @param pageId
-- @param animation
function switchPage(pageId, animation)
	if not apps.switchPage then
		return pushPage(pageId, false)
	end
	
    if not animation then
        animation = false
    end
    return apps.switchPage(pageId, animation)
end

-------------------------------------------------------------------------------
-- Function push
-- @function [parent=#framework.apps] push
-- @param appId
-- @param pageId
-- @param userCurrentStack
function push(appId, pageId, userCurrentStack)
    return apps.push(appId, pageId, userCurrentStack)
end

-------------------------------------------------------------------------------
-- Function pushView
-- @function [parent=#framework.apps] pushView
-- @param model
function pushView(model)
	if apps.pushView then
		apps.pushView(model)
	end
end

-------------------------------------------------------------------------------
-- Function pushPage
-- @function [parent=#framework.apps] pushPage
-- @param pageId
-- @param userCurrentStack
function pushPage(pageId, userCurrentStack)
	if userCurrentStack == nil then
		userCurrentStack = true
	end
    return apps.push(utils.getAppId(sandbox), pageId, userCurrentStack)
end

-------------------------------------------------------------------------------
-- Function reloadPage
-- @function [parent=#framework.apps] reloadPage
function reloadPage()
		if apps.reloadPage then
        return apps.reloadPage()
		end
end

-------------------------------------------------------------------------------
-- Function presentModal
-- @function [parent=#framework.apps] presentModal
-- @param view disableBack
function presentModal(view, disableBack)
    if apps.presentModal then
        apps.presentModal(view, disableBack)
    end
end

-------------------------------------------------------------------------------
-- Function dismissModal
-- @function [parent=#framework.apps] dismissModal
function dismissModal()
	if apps.dismissModal then
		apps.dismissModal()
	end
end

-------------------------------------------------------------------------------
-- Function isPresentModalSupported
-- @function [parent=#framework.apps] isPresentModalSupported
function isPresentModalSupported()
	return apps.presentModal ~= nil
end

-------------------------------------------------------------------------------
-- Function list
-- @function [parent=#framework.apps] list
-- @param category
function list(category)
	local base = require "framework.base"
    local result = base.getGSandbox():listApps(category)
    
    if type(result) == "table" and #(result) > 0 then
    	return result
    elseif result ~= nil then
    	local arr = {}
    	for i=0,result:size()-1 do
    		table.insert(arr, result:get(i))
    	end
    	return arr
    end
end

-------------------------------------------------------------------------------
-- Function pop
-- @function [parent=#framework.apps] pop
-- @param toAppId
function pop(toAppId)
    if not toAppId then
        toAppId = nil
    end
    return apps.pop(toAppId)
end

-------------------------------------------------------------------------------
-- Function popPage
-- @function [parent=#framework.apps] popPage
-- @param toTop
function popPage(toTop)
    if not toTop then
        toTop = false
    end
    return apps.popPage(toTop)
end
