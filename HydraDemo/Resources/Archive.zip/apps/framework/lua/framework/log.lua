---
-- @module framework.log

local loglevel

module(..., package.seeall)

local utils = require "framework.utils"
local storage = require "framework.storage"

local function loadLevel()
	if not loglevel then
		loglevel = storage.load("$loglevel", storage.SCOPE_GLOBAL)
		if not loglevel then
			loglevel = DEBUG
		else
			loglevel = tonumber(loglevel)
		end
	end
end

-------------------------------------------------------------------------------
-- The value of DEBUG.
-- @field [parent=#framework.log] TRACE
TRACE = 1
-------------------------------------------------------------------------------
-- The value of DEBUG.
-- @field [parent=#framework.log] DEBUG
DEBUG = 2
-------------------------------------------------------------------------------
-- The value of INFO.
-- @field [parent=#framework.log] INFO
INFO = 3
-------------------------------------------------------------------------------
-- The value of WARNING.
-- @field [parent=#framework.log] WARNING
WARNING = 4
-------------------------------------------------------------------------------
-- The value of ERROR.
-- @field [parent=#framework.log] ERROR
ERROR = 5

-------------------------------------------------------------------------------
-- Function setLevel
-- @function [parent=#framework.log] setLevel
-- @param level
function setLevel(level)
    loglevel = level
    storage.save("$loglevel", loglevel, storage.SCOPE_GLOBAL)
end

-------------------------------------------------------------------------------
-- Function debug
-- @function [parent=#framework.log] debug
-- @param obj
function debug(str)
	loadLevel()
    if loglevel > DEBUG then
        return
    end
    
    pcall(function() utils.dump("[DEBUG]: " .. utils.objecttostring(str)) end)
end

-------------------------------------------------------------------------------
-- Function isDebug
-- @function [parent=#framework.log] isDebug
function isDebug()
	loadLevel()
    return loglevel <= DEBUG
end

-------------------------------------------------------------------------------
-- Function info
-- @function [parent=#framework.log] info
-- @param obj
function info(str)
	loadLevel()
    if loglevel > INFO then
        return
    end
    
    pcall(function() utils.dump("[INFO]: " .. utils.objecttostring(str)) end)
end

-------------------------------------------------------------------------------
-- Function isInfo
-- @function [parent=#framework.log] isInfo
function isInfo()
	loadLevel()
    return loglevel <= INFO
end

-------------------------------------------------------------------------------
-- Function error
-- @function [parent=#framework.log] error
-- @param obj
function error(str)
	loadLevel()
    if loglevel > ERROR then
        return
    end
    
    pcall(function() utils.dump("[ERROR]: " .. utils.objecttostring(str)) end)
end

-------------------------------------------------------------------------------
-- Function isError
-- @function [parent=#framework.log] isError
function isError()
	loadLevel()
    return loglevel <= ERROR
end

-------------------------------------------------------------------------------
-- Function warning
-- @function [parent=#framework.log] warning
-- @param obj
function warning(str)
	loadLevel()
    if loglevel > WARNING then
        return
    end
    
    pcall(function() utils.dump("[WARNING]: " .. utils.objecttostring(str)) end)
end

-------------------------------------------------------------------------------
-- Function isWarning
-- @function [parent=#framework.log] isWarning
function isWarning()
	loadLevel()
    return loglevel <= WARNING
end

-------------------------------------------------------------------------------
-- Function trace
-- @function [parent=#framework.log] trace
-- @param obj
function trace(str)
	loadLevel()
    if loglevel > TRACE then
        return
    end
    
    pcall(function() utils.dump("[TRACE]: " .. utils.objecttostring(str)) end)
end

-------------------------------------------------------------------------------
-- Function isTrace
-- @function [parent=#framework.log] isTrace
function isTrace()
	loadLevel()
    return loglevel <= TRACE
end


