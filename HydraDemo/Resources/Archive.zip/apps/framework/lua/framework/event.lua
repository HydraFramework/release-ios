---
-- @module framework.event

local eventlist = {}
local eventmap = {}
local table = table
local ipairs = ipairs
local print = print
local require = require

local function _bind(sandbox, key, func)
	if type(sandbox.dispatcher) == "function" then return end
	
	local list = eventmap[key]
	
	if not list then
		list = {}
		eventmap[key] = list
	end
	for k,v in ipairs(list) do
		if v == func then
			print("ignore same func")
			return
		end
	end
	
	local e = sandbox.dispatcher:bind(key, func)
	table.insert(list, func)
	table.insert(eventlist, e)
	
	return e
end

local function _post(sandbox, key, object)
	if type(sandbox.dispatcher) == "function" then return end
	
	sandbox.dispatcher:post(key, object)
end

module(...)

-------------------------------------------------------------------------------
-- The value of DEVICE_SHAKE.
-- @field [parent=#framework.event] DEVICE_SHAKE
DEVICE_SHAKE = "Shake"

-------------------------------------------------------------------------------
-- The value of PUSH_TOKEN_UPDATED.
-- @field [parent=#framework.event] PUSH_TOKEN_UPDATED
PUSH_TOKEN_UPDATED = "PushTokenUpdated"

-------------------------------------------------------------------------------
-- The value of PUSH_NOTIFICATION.
-- @field [parent=#framework.event] PUSH_NOTIFICATION
PUSH_NOTIFICATION = "PushNotification"

-------------------------------------------------------------------------------
-- The value of HANDLE_OPEN_URL.
-- @field [parent=#framework.event] HANDLE_OPEN_URL
HANDLE_OPEN_URL = "HandleOpenURL"

-------------------------------------------------------------------------------
-- The value of FW_HTTP_403_3_1.
-- @field [parent=#framework.event] FW_HTTP_403_3_1
FW_HTTP_403_3_1 = "FW_HTTP_403_3_1"

-------------------------------------------------------------------------------
-- The value of FW_HTTP_403_2_2.
-- @field [parent=#framework.event] FW_HTTP_403_2_2
FW_HTTP_403_2_2 = "FW_HTTP_403_2_2"

-------------------------------------------------------------------------------
-- Function post
-- @function [parent=#framework.event] post
function post(sandbox, key, func)
	return _post(sandbox, key, func)
end

-------------------------------------------------------------------------------
-- Function gpost
-- @function [parent=#framework.event] gpost
function gpost(key, func)
	local base = require "framework.base"
	return _post(base.getGSandbox(), key, func)
end

-------------------------------------------------------------------------------
-- Function bind
-- @function [parent=#framework.event] bind
function bind(sandbox, key, func)
	return _bind(sandbox, key, func)
end

-------------------------------------------------------------------------------
-- Function gbind
-- @function [parent=#framework.event] gbind
function gbind(key, func)
	local base = require "framework.base"
	return _bind(base.getGSandbox(), key, func)
end

-------------------------------------------------------------------------------
-- Function unbind
-- @function [parent=#framework.event] unbind
-- @param e
function unbind(e)
	for k,v in ipairs(eventlist) do
		if v == e then
			table.remove(eventlist, k)
			break
		end
	end
end
