---
--@module framework.utils
local nativeasync = async

local print = print
local utils = require "native.utils"
local base = require "framework.base"
local session = require "framework.session"
local json = require "json"

module(..., package.seeall)

-------------------------------------------------------------------------------
-- Function urlencode
-- @function [parent=#framework.utils] urlencode
-- @param str
function urlencode(str)
	return utils.urlencode(str)
end

-------------------------------------------------------------------------------
-- Function versionCompare
-- @function [parent=#framework.utils] versionCompare
-- @param oldversion
-- @param appversion
function versionCompare(oldversion, appversion)
	return utils.versionCompare(oldversion, appversion)
end

-------------------------------------------------------------------------------
-- Function requestPushToken
-- @function [parent=#framework.utils] requestPushToken
function requestPushToken()
	if utils.registerPush then
		utils.registerPush()
	end
end

-------------------------------------------------------------------------------
-- Function async
-- @function [parent=#framework.utils] async
-- @param func
function async(func)
	if nativeasync then
		nativeasync(func)
	else
		func()
	end
end

-------------------------------------------------------------------------------
-- Function removePath
-- @function [parent=#framework.utils] removePath
-- @param path
function removePath(path)
	local pathattr = lfs.attributes(path)
	if not pathattr then
		return false
	end

	if pathattr.mode ~= "directory" then
		os.remove(path)
		return true
	end

	for file in lfs.dir(path) do
		if file ~= "." and file ~= ".." then
			local f = path..'/'..file
			local attr = lfs.attributes (f)
			if attr.mode == "directory" then
				removePath(f)
			else
				os.remove(f)
			end
		end
	end

	lfs.rmdir(path)
end

-------------------------------------------------------------------------------
-- Function dump
-- @function [parent=#framework.utils] dump
-- @param obj
function dump(o)
	print(o)
end

-------------------------------------------------------------------------------
-- Function getAppId
-- @function [parent=#framework.utils] getAppId
-- @param sandbox
function getAppId(sbx)
	if type(sbx) == "table" then
		return sbx.appId
	else
		return sbx:getAppId()
	end
end

-------------------------------------------------------------------------------
-- Function getAppVersion
-- @function [parent=#framework.utils] getAppVersion
-- @param sandbox
function getAppVersion(sbx)
	if type(sbx) == "table" then
		return sbx.appVersion
	else
		return sbx:getAppVersion()
	end
end

-------------------------------------------------------------------------------
-- Function getLoadModel
-- @function [parent=#framework.utils] getLoadModel
-- @param sandbox
function getLoadModel(sbx)
	if type(sbx) == "table" then
		local ret = sbx.loadModel
		if type(ret) == "string" then
			return ret
		else
			return sbx:getLoadModel()
		end
	else
		return sbx:getLoadModel()
	end
end

-------------------------------------------------------------------------------
-- Function navigateURL
-- @function [parent=#framework.utils] navigateURL
-- @param url
function navigateURL(url)
	local nv = utils.navigateURL
	if nv then
		nv(url)
	end
end

-------------------------------------------------------------------------------
-- Function exit
-- @function [parent=#framework.utils] exit
-- @param code
function exit(num)
	local ex = utils.exit
	if ex then
		if not num then
			num = 0
		end
		ex(num)
	end
end

-------------------------------------------------------------------------------
-- Function takePhoto
-- @function [parent=#framework.utils] takePhoto
-- @param args
function takePhoto(args)
	local tp = utils.takePhoto
	if tp then
		return tp(args)
	end
end

-------------------------------------------------------------------------------
-- Function advancedTakePhoto
-- @function [parent=#framework.utils] advancedTakePhoto
-- @param option
function advancedTakePhoto(option)
	if option and type(option) ~= "table" then
		option = nil
	end
	return helper:advancedTakePhoto(option)
end

-------------------------------------------------------------------------------
-- Function editImage
-- @function [parent=#framework.utils] editImage
-- @param img
-- @param opt
function editImage(img, opt)
	if opt and type(opt) ~= "table" then
		opt = nil
	end
	return helper:editImage_withOption(img, opt)
end

-------------------------------------------------------------------------------
-- Function tojson
-- @function [parent=#framework.utils] tojson
-- @param string
function tojson(o)
	return json.decode(o)
end

-------------------------------------------------------------------------------
-- Function md5String
-- @function [parent=#framework.utils] md5String
-- @param str
function md5String(str)
	return utils.md5String(str)
end

-------------------------------------------------------------------------------
-- Function isEmpty
-- @function [parent=#framework.utils] isEmpty
-- @param obj
function isEmpty(o)
	return o == nil
end

local function table_val_to_str ( v )
	if "string" == type( v ) then
		v = string.gsub( v, "\n", "\\n" )
		if string.match( string.gsub(v,"[^'\"]",""), '^"+$' ) then
			return "'" .. v .. "'"
		end
		return '"' .. string.gsub(v,'"', '\\"' ) .. '"'
	else
		return "table" == type( v ) and table_tostring( v ) or
		objecttostring( v )
	end
end

local function table_key_to_str ( k )
	if "string" == type( k ) and string.match( k, "^[_%a][_%a%d]*$" ) then
		return k
	else
		return "[" .. table_val_to_str( k ) .. "]"
	end
end

-------------------------------------------------------------------------------
-- Function table_tostring
-- @function [parent=#framework.utils] table_tostring
-- @param table
function table_tostring( tbl )
	local result, done = {}, {}
	if #(tbl) > 0 then
		for k, v in ipairs( tbl ) do
			table.insert( result, table_val_to_str( v ) )
			done[ k ] = true
		end
	end
	for k, v in pairs( tbl ) do
		if not done[ k ] then
			table.insert( result,
			table_key_to_str( k ) .. "=" .. table_val_to_str( v ) )
		end
	end
	return "{" .. table.concat( result, "," ) .. "}"
end

-------------------------------------------------------------------------------
-- Function objecttostring
-- @function [parent=#framework.utils] objecttostring
-- @param object
function objecttostring(o)
	if o == nil then
		return "nil"
	end
	local t = type(o)
	if t == "table" then
		return table_tostring(o)
	elseif t == "string" then
		return o
	elseif t == "number" then
		return o
	elseif t == "boolean" then
		return o and "true" or "false"
	end

	return "<unknown type: " .. t .. ">"
end
