---
-- @module framework.track
local mba = require "framework.mba"
local user = require "framework.user"
local utils = require "framework.utils"


module(..., package.seeall)
-------------------------------------------------------------------------------
-- The value of APP_LAUNCH.
-- @field [parent=#framework.track] APP_LAUNCH
APP_LAUNCH = 0x100

-------------------------------------------------------------------------------
-- Function track
-- @function [parent=#framework.track] track
-- @param code
-- @param params
function track(code, params)
	if not code then
		code = 0
	end
	
	if params and type(params) ~= "table" then
		params = { params }
	end
	
    local profile = user.getProfile()
    local sn, ur
    if profile then
    	sn = profile.serialNumber
    	ur = profile.roles
    end
    
	mba.apost("log", nil, {c=code, ct=os.time()*1000, sn=sn, ur=ur, ac=utils.getAppId(sandbox), av=utils.getAppVersion(sandbox), p=params})
end
