---
-- @module framework.cmba

module(..., package.seeall)
local base = require "framework.base"
local services = require "framework.services"
local json = require "json"
local http = require "native.http"

-------------------------------------------------------------------------------
-- Function post
-- @function [parent=#framework.cmba] post
-- @param appId
-- @param intf
-- @param method
-- @param args
function post(appId, intf, method, args)
    local token = base.getToken(appId)
    return services.invoke(token, intf, method, args)
end

-------------------------------------------------------------------------------
-- Function apost
-- @function [parent=#framework.cmba] apost
-- @param appId
-- @param intf
-- @param method
-- @param args
-- @param id
function apost(appId, intf, method, args, id)
    local route = nil
    if intf == "log" and method == nil then
        route = "log"
    elseif intf ~= nil and method ~= nil then
        local token = base.getToken(appId)
        route = token .. "/" .. intf .. "/" .. method
    end
    
    if route and args then
        http.apost(route, json.encode(args), id)
    end
end

-------------------------------------------------------------------------------
-- Function dump_get
-- @function [parent=#framework.cmba] dump_get
-- @param appId
-- @param intf
-- @param method
-- @param args
function dump_get(appId, intf, method, args)
    local token = base.getToken(appId)
    local ret = services.dump_invoke(token, intf, method, args)
    return ret
end
