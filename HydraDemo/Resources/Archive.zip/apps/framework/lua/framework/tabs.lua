---
-- @module framework.tabs

module(..., package.seeall)
local tabs = require "native.tabs"
-------------------------------------------------------------------------------
-- Function updateBadge
-- @function [parent=#framework.tabs] updateBadge
-- @param name
-- @param badge
function updateBadge(name, badge)
    tabs.updateBadge(name, badge)
end

-------------------------------------------------------------------------------
-- Function switch
-- @function [parent=#framework.tabs] switch
-- @param name
function switch(name)
    tabs.switch(name)
end
