---
-- @module framework.mba

module(..., package.seeall)
local base = require "framework.base"
local services = require "framework.services"
local json = require "json"
local http = require "native.http"
local utils = require "framework.utils"
local token = require "framework.token"

-------------------------------------------------------------------------------
-- Function post
-- @function [parent=#framework.mba] post
-- @param intf
-- @param method
-- @param args
function post(intf, method, args)
    local token = base.getToken(utils.getAppId(sandbox))
    return services.invoke(token, intf, method, args)
end

-------------------------------------------------------------------------------
-- Function apost
-- @function [parent=#framework.mba] apost
-- @param intf
-- @param method
-- @param args
-- @param id
function apost(intf, method, args, id)
    local route = nil
    if intf == "log" and method == nil then
        route = "log"
    elseif intf ~= nil and method ~= nil then
        local token = base.getToken(utils.getAppId(sandbox))
        route = token .. "/" .. intf .. "/" .. method
    end
    
    if route and args then
        http.apost(route, json.encode(args), id)
    end
end

-------------------------------------------------------------------------------
-- Function dump_get
-- @function [parent=#framework.mba] dump_get
-- @param intf
-- @param method
-- @param args
function dump_get(intf, method, args)
    local token = base.getToken(utils.getAppId(sandbox))
    local ret = services.dump_invoke(token, intf, method, args)
    return ret
end
