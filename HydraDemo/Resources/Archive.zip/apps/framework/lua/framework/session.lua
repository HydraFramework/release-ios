---
-- @module framework.session

local base = require "framework.base"

module(..., package.seeall)

-------------------------------------------------------------------------------
-- Function getId
-- @function [parent=#framework.session] getId
function getId()
    return base.getGSandbox():get("$sessionId")
end

-------------------------------------------------------------------------------
-- Function setId
-- @function [parent=#framework.session] setId
-- @param sid
function setId(sid)
    base.getGSandbox():put_value("$sessionId", sid)
end

-------------------------------------------------------------------------------
-- Function isOffline
-- @function [parent=#framework.session] isOffline
function isOffline()
	local s = getId()
	return s == nil or s == "$offline"
end

-------------------------------------------------------------------------------
-- Function setOffline
-- @function [parent=#framework.session] setOffline
function setOffline()
	setId("$offline")
end