---
-- @module framework.services
local require = require
local http = require "framework.http"
local session = require "framework.session"
local apps = require "framework.apps"
local base = require "framework.base"
local ui = require "framework.ui"
local utils = require "framework.utils"
local log = require "framework.log"
local user = require "framework.user"
local storage = require "framework.storage"
local json = require "json"

local token = require "framework.token"
local phone = require "framework.phone"

local APP_CACHE_USER = "$app_cache_user"
local APP_CACHE_SYSTEM = "$app_cache_system"

module(..., package.seeall)

-------------------------------------------------------------------------------
-- Function getUserApps
-- @function [parent=#framework.services] getUserApps
function getUserApps()
	local gsbx = base.getGSandbox()
	return gsbx:getList(APP_CACHE_USER)
end

-------------------------------------------------------------------------------
-- Function getSystemApps
-- @function [parent=#framework.services] getSystemApps
function getSystemApps()
	local gsbx = base.getGSandbox()
	return gsbx:getList(APP_CACHE_SYSTEM)
end

-------------------------------------------------------------------------------
-- Function hasNetwork
-- @function [parent=#framework.services] hasNetwork
function hasNetwork()
	if not phone.isWLAN() then
		if ui.confirm("提示", "未找到 WIFI，是否使用 2G/3G 网络下载?", "是", "否", ui.CONFIRM_CANCEL) == ui.CONFIRM_CANCEL then
			return false
		end
	end
	
	return true
end

-------------------------------------------------------------------------------
-- Function updateApps
-- @function [parent=#framework.services] updateApps
-- @param newapps
-- @param oldapps
local function updateApps(newapps, oldapps)
	local fcount = 0
	local lazyCount = 0
	for i,app in ipairs(newapps) do
		local appid = app.id
		local appversion = app.version
		local loadModel = app.loadModel

		local existVersion = ""
		local needUpdate = true
		for j,oldapp in ipairs(oldapps) do
			local oldid = utils.getAppId(oldapp)
			local oldversion = utils.getAppVersion(oldapp)

			if oldid == appid then
				loadModel = oldapp.loadModel
				
				-- hack for patch issue of lazy module 2013.04.03
				if appid == "TheLook2" and (string.find(oldversion, "1.5.0") or string.find(oldversion, "1.5.1")) and oldapp.loadModel == "lazy" then
					local f = io.open(oldapp.appPath .. "/initialize.lua", "r")
					if f then -- installed already with patch issue, load model should not be lazy
						f:close()

						local server = base.getGSandbox():get("env"):get("server")
						if server == "stg" then
							oldversion = "1.3.1-2"
						else
							oldversion = "1.5.0-1"
						end
						loadModel = nil
					end
				end

				existVersion = oldversion
				if utils.versionCompare(oldversion, appversion) >= 0 then
					needUpdate = false
				end
				break
			end
		end

		if needUpdate then
			log.debug(appid .. " not latest")
			local appurl = nil
			if loadModel == "lazy" then
				appurl = base.getServerURL() .. "mobilityapp/" .. appid .. "/" .. appversion .. "/manifest?sessionId=" .. session.getId()
				lazyCount = lazyCount + 1
				storage.save(appid, appversion, "$lazyversion")
			else
				appurl = base.getServerURL() .. "mobilityapp/" .. appid .. "/" .. appversion .. "?sessionId=" .. session.getId() .. "&from=" .. existVersion
				storage.save(appid, existVersion, "$patchfrom")
			end
			print(appurl)
			local issucc = apps.install(appurl, appid, existVersion)
			if not issucc then
				fcount = fcount + 1
			end
		else
			log.debug(appid .. " latest")
			if loadModel == "lazy" then
				storage.save(appid, appversion, "$lazyversion")
			end
		end
	end

	for j,oldapp in ipairs(oldapps) do
		local oldid = utils.getAppId(oldapp)

		local found = false
		for j=1,#(newapps) do
			local app = newapps[j]
			local appid = app["id"]
			if oldid == appid then
				found = true
				break
			end
		end

		if not found then
			--apps.remove(oldid)
		end
	end

	return fcount
end

local function updateAppCache(newapps, categories, appcache)
	local oldapps = apps.list(categories)
	for j=1,#(newapps) do
		local app = newapps[j]
		local appid = app.id
		local apptoken = app.token

		base.setToken(appid, apptoken)
		base.setSize(appid, app.size)

		for i=0,appcache:size()-1 do
			local sbx = appcache:get(i)
			local sbxid = utils.getAppId(sbx)
			if sbxid == appid then
				appcache:removeAt(i)
				break
			end
		end

		for j,oldapp in ipairs(oldapps) do
			local oldid = utils.getAppId(oldapp)
			if oldid == appid then
				appcache:add(oldapp)
				break
			end
		end
	end
end

local function updateAppCategories(all_apps)
	local system_apps = all_apps["system"]
	log.debug(system_apps)

	local fcount = 0
	if system_apps and #(system_apps) > 0 then
		local oldapps = apps.list("system")
		fcount = fcount + updateApps(system_apps, oldapps)

		local gsbx = base.getGSandbox()
		local appcache = gsbx:getList(APP_CACHE_SYSTEM)
		updateAppCache(system_apps, "system", appcache)
	else
		log.debug("system category no update.")
	end

	local user_apps = all_apps["user"]
	if user_apps and #(user_apps) > 0 then
		local olduserapps = apps.list("user")
		fcount = fcount + updateApps(user_apps, olduserapps)

		local gsbx = base.getGSandbox()
		local appcache = gsbx:getList(APP_CACHE_USER)
		updateAppCache(user_apps, "user", appcache)
	else
		log.debug("user category no update.")
	end

	return fcount
end

local function cache_login_body(body)
	if body then
		local enc = algorithm.aes_encrypt(body)
		local hex = algorithm.data2hex(enc)
		storage.save("app.latest_relogin_body", hex, storage.SCOPE_GLOBAL)
	else
		storage.save("app.latest_relogin_body", nil, storage.SCOPE_GLOBAL)
	end
end

-------------------------------------------------------------------------------
-- Function hello
-- @function [parent=#framework.services] hello
function hello()
	local dinfo = base.getDeviceInfo()
	if dinfo == nil then
		return false, nil
	end

	local dinfotb = json.decode(dinfo:tostring())
	
	local gsbx = base.getGSandbox()
	local appcache = gsbx:getList(APP_CACHE_SYSTEM)
	appcache:clear()
	local appcache = gsbx:getList(APP_CACHE_USER)
	appcache:clear()

	local appseed = storage.load("app.seed", storage.SCOPE_GLOBAL)
	if not appseed then
		appseed = tostring(os.time())
		storage.save("app.seed", appseed, storage.SCOPE_GLOBAL)
	end

	local body = "dev.uuid=" .. utils.urlencode(dinfotb["device.uuid"])
	.. "&dev.type=" .. utils.urlencode(dinfotb["device.type"])
	.. "&dev.model=" .. utils.urlencode(dinfotb["device.model"])
	.. "&dev.manufacturer=" .. utils.urlencode(dinfotb["device.manufacturer"])
	.. "&env.netType=" .. utils.urlencode(dinfotb["device.networkType"])
	.. "&dev.resWidth=" .. utils.urlencode(dinfotb["device.resolutionWidth"])
	.. "&dev.resHeight=" .. utils.urlencode(dinfotb["device.resolutionHeight"])
	.. "&os.name=" .. utils.urlencode(dinfotb["os.name"])
	.. "&os.version=" .. utils.urlencode(dinfotb["os.version"])
	.. "&app.name=" .. utils.urlencode(dinfotb["framework.name"])
	.. "&app.version=" .. utils.urlencode(dinfotb["framework.version"])
	.. "&app.seed=" .. appseed

	local retina = dinfotb["device.retina"]
	if retina then
		body = body .. "&dev.retina=" .. retina
	end
	
	local ret = http.post_form(nil, "hello", body)
	local respstatus = true
	if log.isDebug() then
		log.debug(ret)
	end
	
	if ret then
		local fake = false
		local status = (ret.status and ret.status or ret.responseCode)
		if status == 0 then
			local latestbody = storage.load("app.latest_hello_body", storage.SCOPE_GLOBAL)
			if latestbody then
				ret.responseCode = 200
				status = 200
				ret.body = latestbody
				fake = true
			else
				cache_login_body(nil)
			end
		end
		if status == 200 then
			local resp = ret.body
			if not fake then
				storage.save("app.latest_hello_body", resp, storage.SCOPE_GLOBAL)
			end
			
			local respdic = json.decode(resp)
			
			-- Deperacated ClientAppRevision
			if respdic.update then
				local updateMessage = respdic.update.message
				if not updateMessage then
					updateMessage = "发现新版本 " .. respdic.update.version .. "，请问是否需要更新?"
				end
				if ui.confirm("提示", updateMessage, "更新", "忽略", ui.CONFIRM_CANCEL) == ui.CONFIRM_OK then
            		utils.navigateURL(respdic.update.url)
            		utils.exit(0)
				end
            end
            
			local sessionId = respdic["sessionId"]
			session.setId(sessionId)
			
			local environment = respdic["environment"]
			if environment then
				local env = base.getGSandbox():getMap("env")
				for k,v in pairs(environment) do
					env:put_value(k, v)
				end
			end

			local all_apps = respdic["mobilityApps"]
			local fcount = 0
			repeat
				fcount = updateAppCategories(all_apps)
				if fcount > 0 then
					if ui.confirm("提示", "有"..fcount.."个资源下载失败，是否需要重试?", "重试", "忽略", ui.CONFIRM_CANCEL) == ui.CONFIRM_CANCEL then
						break
					end
				end
			until fcount == 0
		else
			respstatus = false
			storage.save("app.latest_hello_body", nil, storage.SCOPE_GLOBAL)
			if log.isError() then
				log.error("Hello Failed, status=" .. status)
			end
		end
	end

	return respstatus, ret
end

local function process_login(ret, silence)
	if ret then
		local status = ret.status and ret.status or ret.responseCode

		if status == 200 then
			local resp = ret["body"];
			local respdic = json.decode(resp)
			local secureCode = respdic.secureCode
			local expireTime = tonumber(respdic.expireTime)
			log.debug(secureCode)

			user.setSecureCode(secureCode, expireTime / 1000.0)

			if respdic.profile.refreshToken then
				token.setRefreshToken(respdic.profile.refreshToken)
			end

			if respdic.profile.accessToken then
				token.setAccessToken(respdic.profile.accessToken)
			end
			
			user.setProfile(respdic.profile)
			user.setLogin(true)

			local all_apps = respdic["mobilityApps"]
			local fcount = 0
			getUserApps():clear()
			repeat
				fcount = updateAppCategories(all_apps)
				if fcount > 0 then
					if ui.confirm("提示", "有"..fcount.."个资源下载失败，是否需要重试?", "重试", "忽略", ui.CONFIRM_CANCEL) == ui.CONFIRM_CANCEL then
						break
					end
				end
			until fcount == 0
			return true, respdic
		elseif status == 403 then
			token.clean()
			cache_login_body(nil)
			
			local body = ret["body"]
			if body then
				local bodydic = json.decode(body)
				local code = bodydic["code"]
				local message = bodydic["message"]

				if code == "3-3" then
					alert("登录失败", "您的账号由于某些原因已被锁定，请耐心等待解锁，或联系客服。", "确认")
				elseif code == "3-2" then
					if not silence then
						alert("登录失败", "您的用户名与密码不符，请重新输入。", "确认")
					end
				end
			end
		elseif status == 0 then
			alert("连接失败", "未找到有效的网络连接，请确认您的网络设置。", "确认")
		end

		return false, status, ret
	end
	return false, 0
end

-------------------------------------------------------------------------------
-- Function relogin
-- @function [parent=#framework.services] relogin
function relogin()
	local sc = token.getRefreshToken()

	if not sc then
		return false, "no refresh token"
	end


	local body = "secureCode=" .. utils.urlencode(sc)

	http.setSecure(true)
	local ret = http.post_form(nil, "relogin", body)
	http.setSecure(false)
	log.debug(ret)
	
	local status = ret.status and ret.status or ret.responseCode

	if status == 0 then
		ret = http.post_form(nil, "relogin", body)
		status = ret.responseCode
		log.debug(ret)
	end
	
	local fake = false
	if status == 0 then
		local hex = storage.load("app.latest_relogin_body", storage.SCOPE_GLOBAL)
		if hex then
			local enc = algorithm.hex2data(hex)
			local latestrelogin = algorithm.aes_decrypt(enc)
		
			if latestrelogin then
				ret.status = 200
				ret.body = latestrelogin
				fake = true
				base.getGSandbox():put_value("$offline", "true")
			end
		end
	end
	
	if not fake and status == 200 then
		cache_login_body(ret.body)
	end
	return process_login(ret, true)
end

-------------------------------------------------------------------------------
-- Function login
-- @function [parent=#framework.services] login
-- @param username
-- @param password
-- @param domain
function login(username, password, domain, silence)
	token.clean()
	if not session.getId() then
		hello()
	end
	local body = "loginName=" .. utils.urlencode(username) .. "&password=" .. utils.urlencode(password)

	if domain then
		body = body .. "&domain=" .. utils.urlencode(domain)
	end

	http.setSecure(true)
	local ret = http.post_form(nil, "login", body)
	http.setSecure(false)
	log.debug(ret)
	
	local status = ret.status and ret.status or ret.responseCode
	
	if status == 0 then
		ret = http.post_form(nil, "login", body)
		log.debug(ret)
	end
	
	if status == 200 then
		cache_login_body(ret.body)
	end
	return process_login(ret, silence)
end

-------------------------------------------------------------------------------
-- Function refreshApps
-- @function [parent=#framework.services] refreshApps
function refreshApps()
	local ret = http.post_form(nil, "mobilityapps", nil)
	log.debug(ret)

	if ret then
		local status = ret.status and ret.status or ret.responseCode

		if status == 200 then
			local resp = ret["body"];
			local respdic = json.decode(resp)

			local all_apps = respdic.mobilityApps
			all_apps.system = nil -- disable system update durning refresh
			getUserApps():clear()
			local fcount = 0
			repeat
				fcount = updateAppCategories(all_apps)
				if fcount > 0 then
					if ui.confirm("提示", "有"..fcount.."个资源下载失败，是否需要重试?", "重试", "忽略", ui.CONFIRM_CANCEL) == ui.CONFIRM_CANCEL then
						break
					end
				end
			until fcount == 0
			return true, respdic
		end
		return false, status
	end
	return false, 0
end

-------------------------------------------------------------------------------
-- Function refresh
-- @function [parent=#framework.services] refresh
-- @param update_app
function refresh(update_app)
	local ret = http.post_form(nil, "refresh", string.format("at=%s", token.getAccessToken()))
	log.debug(ret)

	if ret then
		local status = ret.status and ret.status or ret.responseCode

		if status == 200 then
			local resp = ret.body
			local respdic = json.decode(resp)
			local secureCode = respdic["secureCode"]
			local expireTime = tonumber(respdic.expireTime)

			user.setSecureCode(secureCode, expireTime / 1000.0)
			if respdic.profile.refreshToken then
				token.setRefreshToken(respdic.profile.refreshToken)
			end

			if respdic.profile.accessToken then
				token.setAccessToken(respdic.profile.accessToken)
			end

			user.setProfile(respdic.profile)
			user.setLogin(true)

			if update_app then
				local all_apps = respdic["mobilityApps"]
				all_apps["system"] = nil -- disable system update durning refresh
				getUserApps():clear()
				local fcount = 0
				repeat
					fcount = updateAppCategories(all_apps)
					if fcount > 0 then
						if ui.confirm("提示", "有"..fcount.."个资源下载失败，是否需要重试?", "重试", "忽略", ui.CONFIRM_CANCEL) == ui.CONFIRM_CANCEL then
							break
						end
					end
				until fcount == 0
			end
			return true, respdic
		elseif status == 403 then
			local resp = ret.body
			local respdic = json.decode(resp)
			
			local code = respdic["code"]
			if code == "3-2" and token.update() then
				return refresh(update_app)
			else
				user.setLogin(false)
				token.clean()
				user.setProfile(nil)
			end
		elseif status == 0 then
		end
		return false, status
	end
	return false, 0
end

-------------------------------------------------------------------------------
-- Function requestPushToken
-- @function [parent=#framework.services] requestPushToken
function requestPushToken()
	utils.requestPushToken()
end

-------------------------------------------------------------------------------
-- Function updatePushToken
-- @function [parent=#framework.services] updatePushToken
-- @param token
function updatePushToken(token)
	local ret = http.get(nil, "update?env.pushToken=" .. token)
	if ret then
		if (ret.status and ret.status or ret.responseCode) == 200 then
			log.info("push token update success!")
		else
			log.info("push token update failed!")
		end
	else
		log.info("network error!")
	end
end

-------------------------------------------------------------------------------
-- Function logout
-- @function [parent=#framework.services] logout
function logout()
	local gsbx = base.getGSandbox()
	local appcache = gsbx:getList(APP_CACHE_USER)
	appcache:clear()

	local secureCode = user.getSecureCode()
	if secureCode then
		ui.startBusy()
		local ret = http.post_form(nil, "logout", "secureCode=" .. secureCode)
		ui.stopBusy()

		user.setLogin(false)
		token.clean()
		user.setProfile(nil)
		
		if ret then
			local status = ret.status and ret.status or ret.responseCode
			if status == 200 then
				return true, ret["body"]
			else
				return false, status
			end
		end
	end
	return false, nil
end

local function make_body(api, intf, method, args)
	if not api then
		return nil
	end
	local sessionId = session.getId()
	if sessionId then
		local at = token.getAccessToken()
		local body = nil
		if at then
		    body = "api=" .. api .. "&intf=" .. intf .. "&method=" .. method .. "&at=" .. at
                else
        	    body = "api=" .. api .. "&intf=" .. intf .. "&method=" .. method
	    	end

		if args then
			if type(args) == "table" and #(args) > 0 then
				for k=1,#(args) do
					local arg = args[k]
					if type(arg) == "table" then
						body = body .. "&args[" .. (k - 1) .. "]=" .. utils.urlencode(json.encode(arg))
					else
						body = body .. "&args[" .. (k - 1) .. "]=" .. utils.urlencode(tostring(arg))
					end
				end
			else
				if type(args) == "table" then
					body = body .. "&args[0]=" .. utils.urlencode(json.encode(args))
				else
					body = body .. "&args[0]=" .. utils.urlencode(tostring(args))
				end
			end
		end
		
		return body
	end
	
	return nil
end

-------------------------------------------------------------------------------
-- Function dump_invoke
-- @function [parent=#framework.services] dump_invoke
-- @param api
-- @param intf
-- @param method
-- @param args
function dump_invoke(api, intf, method, args)
	local body = make_body(api, intf, method, args)
	if body then
		return http.dump_get("invoke?" .. body)
	end

	return false, nil
end

-------------------------------------------------------------------------------
-- Function invoke
-- @function [parent=#framework.services] invoke
-- @param api
-- @param intf
-- @param method
-- @param args
function invoke(api, intf, method, args)
	local body = make_body(api, intf, method, args)
	if not body then
		return false, "parameters error"
	end
	
	local ret = http.post_form(nil, "invoke", body)

	if ret then
		local status = ret.status and ret.status or ret.responseCode
		if status == 200 then
			local headers = ret["headers"]
			local eos_user = headers["EOS-User"]
			if eos_user == "refresh" then
				refresh(true)
				base.getGSandbox():put_value("$eos_user_flag", eos_user)
			end
			return true, ret.body
		elseif status == 401 then
			if token.update() then
				return invoke(api, intf, method, args)
			else
				local storage = require "framework.storage"
				storage.save("app.latest_relogin_body", nil, storage.SCOPE_GLOBAL) -- clear auto login

				local Event = require "framework.event"
				timer = setTimeout(function()
					Event.gpost(Event.FW_HTTP_403_3_1)
				end, 1)
				
				return false, status, ret
			end
		else
			return false, status, ret
		end
	end

	return false, nil
end
