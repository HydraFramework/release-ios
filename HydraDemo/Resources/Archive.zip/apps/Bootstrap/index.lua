local log = require "framework.log"
local apps = require "framework.apps"
local services = require "framework.services"
local ui = require "framework.ui"
local session = require "framework.session"
local utils = require "framework.utils"

local registry = registry

function doHello()
	ui.startBusy("60%", res:get("booting"))

	-- Let's remove the old TheLook permanently
	local appmanagementservice = registry.getService("appmanagement")
	appmanagementservice:remove("TheLook")

	local status = services.hello()

	ui.stopBusy()

	apps.switch("Login")
end

function onFronted(object)
	utils.async(doHello)
end

function onDestroy(object)
end

function onCreated(object)
end

function onIdle(object)
end
