--[[
The EOS framework will call this function,
when the mobility app has been successfully installed.
]]
function onInstalled()
end
 
--[[
The EOS framework will call this function,
when the mobility app has been successfully patched.
]]
function onPatched(oldVersion)
end
